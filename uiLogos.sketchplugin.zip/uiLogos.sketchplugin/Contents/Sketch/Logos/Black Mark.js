@import '../js/common.js'
@import '../js/getLogo.js'

function onRun(context){
    getLogos(context, 'data/logos/mark/black/')
}
